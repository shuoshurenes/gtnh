# -*- coding: utf-8 -*-
"""
神秘时代 · 要素连线工具（主干生长 + 联合 A* 强化版 v3）

规则实现：
  [网格层] 不穿障碍、不穿未接入的绿点；步数奇偶与直线距离一致；步数相同时才偏向直行。
  [要素层] 相邻要素必须在要素图中相连、不得连续同名；禁用要素绝不作为中间点。
  [网络层] 中位点生根 + 每轮全局最便宜接入 + 多起点取最优 + 建完重接（rewire），
           只允许在已有主干上分叉，不重复铺线，尽量少铺黄格。
  [性能]   计算放入后台线程，结果经队列回主线程更新，界面不再假死。
"""

import math
import random
import time
import json
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk
import collections
import threading
import heapq
import queue

# ============================================================
# 1. 要素数据 (初始权重)
# ============================================================
RAW = {
    'Aer': dict(cn='风', tier=1, cost=4, links=['Lux','Motus','Tempestas','Vacuos','Volatus','Arbor','Auram','Sensus']),
    'Aqua': dict(cn='水', tier=1, cost=2, links=['Tempestas','Venenum','Victus','Limus']),
    'Ignis': dict(cn='火', tier=1, cost=4, links=['Gelum','Lux','Potentia','Infernus','Cognitio','Telum','Ira']),
    'Ordo': dict(cn='秩序', tier=1, cost=0, links=['Motus','Permutatio','Potentia','Vitreus','Sano','Tempus','Aequalitas','Instrumentum']),
    'Perditio': dict(cn='混沌', tier=1, cost=2, links=['Gelum','Permutatio','Vacuos','Venenum','Mortuus','Vinculum','Vitium','Strontio']),
    'Terra': dict(cn='地', tier=1, cost=4, links=['Victus','Vitreus','Herba','Iter','Metallum','Perfodio','Tutamen']),
    'Gelum': dict(cn='寒冰', tier=2, cost=64, links=['Ignis','Perditio']),
    'Lux': dict(cn='光明', tier=2, cost=8, links=['Ignis','Aer','Radio','Tenebrae','Astrum']),
    'Motus': dict(cn='移动', tier=2, cost=4, links=['Ordo','Aer','Bestia','Iter','Primordium','Vinculum','Volatus','Exanimis','Machina']),
    'Permutatio': dict(cn='交换', tier=2, cost=16, links=['Perditio','Ordo']),
    'Potentia': dict(cn='能量', tier=2, cost=2, links=['Ignis','Ordo','Praecantatio','Radio','Electrum']),
    'Tempestas': dict(cn='气候', tier=2, cost=64, links=['Aqua','Aer']),
    'Vacuos': dict(cn='虚空', tier=2, cost=8, links=['Perditio','Aer','Fames','Praecantatio','Primordium','Tempus','Tenebrae','Alienis','Gula','Superbia']),
    'Venenum': dict(cn='毒药', tier=2, cost=64, links=['Aqua','Perditio']),
    'Victus': dict(cn='生命', tier=2, cost=8, links=['Aqua','Terra','Bestia','Fames','Herba','Limus','Mortuus','Sano','Spiritus']),
    'Vitreus': dict(cn='水晶', tier=2, cost=2, links=['Ordo','Terra','Metallum','Caelum']),
    'Bestia': dict(cn='野兽', tier=3, cost=64, links=['Motus','Victus','Corpus','Humanus','Pannus']),
    'Fames': dict(cn='饥饿', tier=3, cost=64, links=['Vacuos','Victus','Gula','Luxuria','Lucrum','Invidia']),
    'Herba': dict(cn='植物', tier=3, cost=4, links=['Terra','Victus','Arbor','Messis']),
    'Iter': dict(cn='旅行', tier=3, cost=4, links=['Motus','Terra','Magneto','Gloria','Tabernus']),
    'Limus': dict(cn='史莱姆', tier=3, cost=16, links=['Aqua','Victus']),
    'Metallum': dict(cn='金属', tier=3, cost=0, links=['Vitreus','Terra','Caelum','Magneto']),
    'Mortuus': dict(cn='死亡', tier=3, cost=64, links=['Perditio','Victus','Corpus','Exanimis','Spiritus']),
    'Praecantatio': dict(cn='魔力', tier=3, cost=8, links=['Vacuos','Potentia','Auram','Infernus','Vitium']),
    'Primordium': dict(cn='起始', tier=3, cost=512, links=['Vacuos','Motus','Astrum']),
    'Radio': dict(cn='辐射', tier=3, cost=64, links=['Lux','Potentia']),
    'Sano': dict(cn='治疗', tier=3, cost=64, links=['Ordo','Victus']),
    'Tempus': dict(cn='时间', tier=3, cost=64, links=['Vacuos','Ordo']),
    'Tenebrae': dict(cn='黑暗', tier=3, cost=16, links=['Vacuos','Lux','Alienis']),
    'Vinculum': dict(cn='陷阱', tier=3, cost=16, links=['Motus','Perditio','Desidia']),
    'Volatus': dict(cn='飞行', tier=3, cost=8, links=['Motus','Aer','Superbia']),
    'Alienis': dict(cn='异域', tier=4, cost=8, links=['Vacuos','Tenebrae','Terminus']),
    'Arbor': dict(cn='树木', tier=4, cost=4, links=['Herba','Aer']),
    'Astrum': dict(cn='星辰', tier=4, cost=512, links=['Lux','Primordium']),
    'Auram': dict(cn='灵气', tier=4, cost=64, links=['Praecantatio','Aer']),
    'Caelum': dict(cn='宙空', tier=4, cost=512, links=['Vitreus','Metallum']),
    'Corpus': dict(cn='肉体', tier=4, cost=16, links=['Mortuus','Bestia','Luxuria']),
    'Exanimis': dict(cn='亡灵', tier=4, cost=16, links=['Motus','Mortuus']),
    'Gula': dict(cn='饕餮', tier=4, cost=16, links=['Vacuos','Fames']),
    'Infernus': dict(cn='下界', tier=4, cost=64, links=['Ignis','Praecantatio']),
    'Magneto': dict(cn='磁力', tier=4, cost=16, links=['Metallum','Iter']),
    'Spiritus': dict(cn='灵魂', tier=4, cost=64, links=['Mortuus','Victus','Cognitio','Desidia','Sensus']),
    'Superbia': dict(cn='傲慢', tier=4, cost=64, links=['Vacuos','Volatus']),
    'Vitium': dict(cn='腐化', tier=4, cost=64, links=['Praecantatio','Perditio','Vesania']),
    'Cognitio': dict(cn='认知', tier=5, cost=4, links=['Ignis','Spiritus','Aequalitas','Humanus','Strontio','Vesania']),
    'Desidia': dict(cn='怠惰', tier=5, cost=64, links=['Vinculum','Spiritus']),
    'Luxuria': dict(cn='欲望', tier=5, cost=512, links=['Fames','Corpus']),
    'Sensus': dict(cn='感官', tier=5, cost=4, links=['Spiritus','Aer','Invidia']),
    'Aequalitas': dict(cn='平等', tier=6, cost=512, links=['Ordo','Cognitio']),
    'Humanus': dict(cn='人类', tier=6, cost=64, links=['Bestia','Cognitio','Gloria','Instrumentum','Lucrum','Messis','Perfodio','Fabrico']),
    'Invidia': dict(cn='妒忌', tier=6, cost=512, links=['Sensus','Fames']),
    'Strontio': dict(cn='愚蠢', tier=6, cost=64, links=['Perditio','Cognitio']),
    'Vesania': dict(cn='疯癫', tier=6, cost=512, links=['Vitium','Cognitio']),
    'Gloria': dict(cn='荣耀', tier=7, cost=512, links=['Iter','Humanus']),
    'Instrumentum': dict(cn='工具', tier=7, cost=0, links=['Ordo','Humanus','Fabrico','Machina','Meto','Pannus','Telum','Tutamen']),
    'Lucrum': dict(cn='贪婪', tier=7, cost=4, links=['Fames','Humanus','Nebrisum','Terminus']),
    'Messis': dict(cn='作物', tier=7, cost=16, links=['Herba','Humanus','Meto']),
    'Perfodio': dict(cn='矿藏', tier=7, cost=64, links=['Terra','Humanus','Nebrisum']),
    'Fabrico': dict(cn='合成', tier=8, cost=0, links=['Instrumentum','Humanus']),
    'Machina': dict(cn='机械', tier=8, cost=1, links=['Motus','Instrumentum','Electrum']),
    'Meto': dict(cn='收获', tier=8, cost=64, links=['Messis','Instrumentum']),
    'Nebrisum': dict(cn='欺骗', tier=8, cost=64, links=['Perfodio','Lucrum']),
    'Pannus': dict(cn='布匹', tier=8, cost=8, links=['Bestia','Instrumentum']),
    'Telum': dict(cn='武器', tier=8, cost=16, links=['Ignis','Instrumentum','Ira']),
    'Terminus': dict(cn='终结', tier=8, cost=512, links=['Lucrum','Alienis']),
    'Tutamen': dict(cn='装备', tier=8, cost=4, links=['Terra','Instrumentum','Tabernus']),
    'Electrum': dict(cn='电力', tier=9, cost=1, links=['Potentia','Machina']),
    'Ira': dict(cn='暴怒', tier=9, cost=64, links=['Telum','Ignis']),
    'Tabernus': dict(cn='靴子', tier=9, cost=64, links=['Tutamen','Iter']),
}

PINYIN_MAP = {
    '风': ('feng', 'f'), '水': ('shui', 's'), '火': ('huo', 'h'), '秩序': ('zhixu', 'zx'),
    '混沌': ('hundun', 'hd'), '地': ('di', 'd'), '寒冰': ('hanbing', 'hb'), '光明': ('guangming', 'gm'),
    '移动': ('yidong', 'yd'), '交换': ('jiaohuan', 'jh'), '能量': ('nengliang', 'nl'), '气候': ('qihou', 'qh'),
    '虚空': ('xukong', 'xk'), '毒药': ('duyao', 'dy'), '生命': ('shengming', 'sm'), '水晶': ('shuijing', 'sj'),
    '野兽': ('yeshou', 'ys'), '饥饿': ('jie', 'j'), '植物': ('zhiwu', 'zw'), '旅行': ('lvxing', 'lx'),
    '史莱姆': ('shilaimu', 'slm'), '金属': ('jinshu', 'js'), '死亡': ('siwang', 'sw'), '魔力': ('moli', 'ml'),
    '起始': ('qishi', 'qs'), '辐射': ('fushe', 'fs'), '治疗': ('zhiliao', 'zl'), '时间': ('shijian', 'sj'),
    '黑暗': ('heian', 'ha'), '陷阱': ('xianjing', 'xj'), '飞行': ('feixing', 'fx'), '异域': ('yiyu', 'yy'),
    '树木': ('shumu', 'sm'), '星辰': ('xingchen', 'xc'), '灵气': ('lingqi', 'lq'), '宙空': ('zhoukong', 'zk'),
    '肉体': ('routi', 'rt'), '亡灵': ('wangling', 'wl'), '饕餮': ('taotie', 'tt'), '下界': ('xiajie', 'xj'),
    '磁力': ('cili', 'cl'), '灵魂': ('linghun', 'lh'), '傲慢': ('aoman', 'am'), '腐化': ('fuhua', 'fh'),
    '认知': ('renzhi', 'rz'), '怠惰': ('daiduo', 'dd'), '欲望': ('yuwang', 'yw'), '感官': ('ganguan', 'gg'),
    '平等': ('pingdeng', 'pd'), '人类': ('renlei', 'rl'), '妒忌': ('duji', 'dj'), '愚蠢': ('yuchun', 'yc'),
    '疯癫': ('fengdian', 'fd'), '荣耀': ('rongyao', 'ry'), '工具': ('gongju', 'gj'), '贪婪': ('tanlan', 'tl'),
    '作物': ('zuowu', 'zw'), '矿藏': ('kuangcang', 'kc'), '工艺': ('gongyi', 'gy'), '机械': ('jixie', 'jx'),
    '收获': ('shouhuo', 'sh'), '欺骗': ('qipian', 'qp'), '布匹': ('bupi', 'bp'), '武器': ('wuqi', 'wq'),
    '终结': ('zhongjie', 'zj'), '装备': ('zhuangbei', 'zb'), '电力': ('dianli', 'dl'), '暴怒': ('baonu', 'bn'),
    '靴子': ('xuezi', 'xz')
}

DEFAULT_COSTS = {k: v['cost'] for k, v in RAW.items()}

ASPECTS = {}
for _k, _v in RAW.items():
    ASPECTS[_k] = dict(_v, key=_k, neighbors=set(), disabled=False)
    cn = _v['cn']
    if cn in PINYIN_MAP:
        ASPECTS[_k]['py_full'] = PINYIN_MAP[cn][0]
        ASPECTS[_k]['py_short'] = PINYIN_MAP[cn][1]
    else:
        ASPECTS[_k]['py_full'] = ''
        ASPECTS[_k]['py_short'] = ''

for _k, _v in RAW.items():
    for _nb in _v['links']:
        if _nb not in ASPECTS: continue
        ASPECTS[_k]['neighbors'].add(_nb)
        ASPECTS[_nb]['neighbors'].add(_k)

HEX_DIRS = [(1, 0), (1, -1), (0, -1), (-1, 0), (-1, 1), (0, 1)]

BG        = '#0d0d1a'
PANEL_BG  = '#141428'
PANEL_BG2 = '#1a1a2e'
BORDER    = '#2a2a4a'
TEXT      = '#d0d0e0'
HEX_EMPTY = '#111120'
HEX_FILL  = '#1a1a3a'
GREEN     = '#00ff88'
YELLOW    = '#ffcc00'
BLUE      = '#00aaff'
RED       = '#ff5555'
OBS_COLOR = '#3a1010'
OBS_LINE  = '#882222'

# ============================================================
# 2. 数学与图论工具
# ============================================================
def axial_to_pixel(q, r, size):
    x = size * 1.5 * q
    y = size * math.sqrt(3) * (r + q / 2.0)
    return x, y

def axial_round(q, r):
    s = -q - r
    rq, rr, rs = round(q), round(r), round(s)
    dq, dr, ds = abs(rq - q), abs(rr - r), abs(rs - s)
    if dq > dr and dq > ds: rq = -rr - rs
    elif dr > ds: rr = -rq - rs
    return rq, rr

def hex_distance(a, b):
    return max(abs(a[0] - b[0]), abs(a[1] - b[1]), abs((-a[0]-a[1]) - (-b[0]-b[1])))

def hex_polygon(cx, cy, size):
    pts = []
    for i in range(6):
        ang = math.radians(60 * i)
        pts.append(cx + size * math.cos(ang))
        pts.append(cy + size * math.sin(ang))
    return pts

def get_logical_dist(start, end):
    """BFS计算图上的最短逻辑距离，用于剪枝和快速判断"""
    if start == end: return 0
    q = collections.deque([(start, 0)])
    visited = {start}
    while q:
        node, d = q.popleft()
        for nb in ASPECTS[node]['neighbors']:
            if not ASPECTS[nb].get('disabled') and nb not in visited:
                if nb == end: return d + 1
                visited.add(nb)
                q.append((nb, d + 1))
    return 999

# ============================================================
# 5. 主应用
# ============================================================
class HexAspectApp:
    def __init__(self, root):
        self.root = root
        root.title('神秘时代 · 要素连线工具')
        root.geometry('1500x950')
        root.minsize(320, 220)          # 允许自由缩小，方便盖在游戏窗口旁边
        root.resizable(True, True)
        root.configure(bg=BG)

        fams = set(tkfont.families())
        self.cn_font = 'TkDefaultFont'
        for f in ('Microsoft YaHei UI', 'Microsoft YaHei', 'PingFang SC', 'Hiragino Sans GB', 'Noto Sans CJK SC', 'Source Han Sans SC', 'WenQuanYi Micro Hei', 'SimHei'):
            if f in fams:
                self.cn_font = f
                break

        self.cols = 20
        self.rows = 20
        self.hex_size = 20
        self.offset_x = 0.0
        self.offset_y = 0.0
        self.cells = {}
        self.paths = []
        self.selected_aspect = None
        self.placed_order = []
        self.order_counter = 0
        self.hover_cell = None
        
        self.show_lines = tk.BooleanVar(value=False)
        self.is_obstacle_mode = tk.BooleanVar(value=False)
        self.is_dragging_obstacle = False
        self.is_dragging_erase = False

        # 工作线程 -> 主线程的唯一通道；工作线程里绝不直接调用 Tk
        self._result_queue = queue.Queue()
        self._computing = False
        self._render_job = None

        # 视图：Ctrl+滚轮缩放、左键拖动平移
        self.zoom = 1.0
        self.pan_x = 0.0
        self.pan_y = 0.0
        self._press_pos = None
        self._last_pos = None
        self._panning = False
        self._obstacle_paint = False

        # 操作记录（Ctrl+Z 撤回）
        self._undo_stack = []
        self._stroke_snapshot = None
        self._stroke_dirty = False

        self.topmost_var = tk.BooleanVar(value=True)

        self._build_ui()
        self._init_grid()
        self._populate_tree()
        self.root.after(80, self.redraw)
        # 默认置顶：可以直接盖在游戏窗口上
        self.root.attributes('-topmost', True)

    def _build_ui(self):
        sidebar = tk.Frame(self.root, bg=PANEL_BG, width=280)
        self.sidebar = sidebar
        sidebar.pack(side='left', fill='y')
        sidebar.pack_propagate(False)

        tk.Label(sidebar, text='神秘时代 · 要素连线',
                 bg=PANEL_BG, fg='#aaaaff',
                 font=(self.cn_font, 12, 'bold'),
                 anchor='w', padx=14, pady=10).pack(fill='x')

        top_row = tk.Frame(sidebar, bg=PANEL_BG)
        top_row.pack(fill='x', padx=10, pady=(0, 4))
        tk.Checkbutton(top_row, text='📌 窗口置顶（盖在游戏上）',
                       variable=self.topmost_var, command=self._toggle_topmost,
                       bg=PANEL_BG, fg=TEXT, selectcolor=BG,
                       activebackground=PANEL_BG, activeforeground='#ffffff',
                       font=(self.cn_font, 9), anchor='w', bd=0,
                       highlightthickness=0).pack(side='left')

        wf = tk.Frame(sidebar, bg=PANEL_BG2, padx=10, pady=6)
        wf.pack(fill='x', padx=8, pady=(0, 6))

        self.edit_label = tk.Label(wf, text='选中要素以修改权重', bg=PANEL_BG2, fg=TEXT,
                                   font=(self.cn_font, 9), anchor='w')
        self.edit_label.pack(fill='x')

        row = tk.Frame(wf, bg=PANEL_BG2)
        row.pack(fill='x', pady=(4, 0))

        tk.Label(row, text='权重:', bg=PANEL_BG2, fg=TEXT, font=(self.cn_font, 9)).pack(side='left')
        self.cost_var = tk.StringVar()
        self.cost_entry = tk.Entry(row, textvariable=self.cost_var, width=6,
                                   bg=BG, fg=TEXT, insertbackground=TEXT,
                                   relief='flat', highlightthickness=1,
                                   highlightbackground=BORDER, highlightcolor='#4444aa',
                                   font=(self.cn_font, 9))
        self.cost_entry.pack(side='left', padx=6, ipady=2)
        self.cost_entry.bind('<Return>', self._apply_cost)

        self._make_button(row, '应用', self._apply_cost, bg='#2a4a8a', fg='#fff', small=True).pack(side='left')
        self._make_button(wf, '恢复默认权重', self._reset_costs, bg='#3a1a1a', fg='#ff9999', small=True).pack(fill='x', pady=(4, 0))

        self.disable_btn = self._make_button(
            wf, '🚫 禁用此要素', self._toggle_disable,
            bg='#1a1a2e', fg='#555555', small=True
        )
        self.disable_btn.config(state='disabled')
        self.disable_btn.pack(fill='x', pady=(4, 0))

        self.search_var = tk.StringVar()
        self.search_var.trace_add('write', lambda *_: self._populate_tree())
        sf = tk.Frame(sidebar, bg=PANEL_BG)
        sf.pack(fill='x', padx=10, pady=(2, 6))
        self.search_entry = tk.Entry(sf, textvariable=self.search_var,
                 bg=BG, fg=TEXT, insertbackground=TEXT,
                 relief='flat', highlightthickness=1,
                 highlightbackground=BORDER, highlightcolor='#4444aa',
                 font=(self.cn_font, 10))
        self.search_entry.pack(fill='x', ipady=4)
        self._add_placeholder(self.search_entry, "输入名称 / 拼音 / 首字母...")

        style = ttk.Style()
        try: style.theme_use('clam')
        except tk.TclError: pass
        style.configure('Treeview', background=PANEL_BG, fieldbackground=PANEL_BG,
                        foreground=TEXT, rowheight=22, borderwidth=0,
                        font=(self.cn_font, 9))
        style.configure('Treeview.Heading', background=PANEL_BG2,
                        foreground='#8888cc', borderwidth=0,
                        font=(self.cn_font, 9, 'bold'))
        style.map('Treeview', background=[('selected', '#2a2a5a')],
                  foreground=[('selected', '#ffffff')])

        tf = tk.Frame(sidebar, bg=PANEL_BG)
        tf.pack(fill='both', expand=True, padx=6, pady=(0, 6))
        self.tree = ttk.Treeview(tf, columns=('en', 'cost'), show='tree headings', selectmode='browse')
        self.tree.heading('#0', text='名称', anchor='w')
        self.tree.heading('en', text='English', anchor='w')
        self.tree.heading('cost', text='权重', anchor='e')
        self.tree.column('#0', width=60, anchor='w')
        self.tree.column('en', width=110, anchor='w')
        self.tree.column('cost', width=45, anchor='e')
        self.tree.tag_configure('disabled', foreground='#666680')
        vsb = ttk.Scrollbar(tf, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side='left', fill='both', expand=True)
        vsb.pack(side='right', fill='y')
        self.tree.bind('<<TreeviewSelect>>', self._on_tree_select)
        self.tree.bind('<Button-1>', self._on_tree_click, add='+')

        tk.Label(sidebar, text='已放置 ORDER', bg=PANEL_BG, fg='#8888cc',
                 font=(self.cn_font, 9, 'bold'), anchor='w', padx=14, pady=2).pack(fill='x')

        pf = tk.Frame(sidebar, bg=PANEL_BG)
        pf.pack(fill='x', padx=6, pady=(0, 4))
        self.placed_tree = ttk.Treeview(pf, columns=(), show='tree', selectmode='browse', height=5)
        self.placed_tree.column('#0', width=240, anchor='w')
        vsb2 = ttk.Scrollbar(pf, orient='vertical', command=self.placed_tree.yview)
        self.placed_tree.configure(yscrollcommand=vsb2.set)
        self.placed_tree.pack(side='left', fill='x', expand=True)
        vsb2.pack(side='right', fill='y')
        self.placed_tree.bind('<Double-Button-1>', self._on_placed_double_click)

        tk.Label(sidebar, text='左键放置 · 右键移除 · Ctrl+左键平移 · Ctrl+滚轮缩放 · Ctrl+Z 撤回',
                 bg=PANEL_BG, fg='#444466', font=(self.cn_font, 8), anchor='w',
                 padx=14, pady=4).pack(side='bottom', fill='x')

        main = tk.Frame(self.root, bg=BG)
        self.main_area = main
        main.pack(side='left', fill='both', expand=True)

        toolbar = tk.Frame(main, bg=PANEL_BG, height=48)
        toolbar.pack(fill='x')
        toolbar.pack_propagate(False)

        self.connect_btn = self._make_button(toolbar, '⚡ 自动连线', self.auto_connect,
                          bg='#2a4a8a', fg='#ffffff', bold=True)
        self.connect_btn.pack(side='left', padx=(12, 6), pady=8)
        
        self._make_button(toolbar, '🗑 清空', self.clear_all,
                          bg='#3a1a1a', fg='#ff9999').pack(side='left', padx=6, pady=8)

        self._make_button(toolbar, '⤢ 重置视图', self.reset_view,
                          bg='#1e1e3a', fg='#c0c0e0', small=True).pack(side='left', padx=6, pady=8)

        self._make_button(toolbar, '↶ 撤回', self.undo,
                          bg='#1e1e3a', fg='#c0c0e0', small=True).pack(side='left', padx=6, pady=8)

        self._make_button(toolbar, '☰ 侧栏', self._toggle_sidebar,
                          bg='#1e1e3a', fg='#c0c0e0', small=True).pack(side='left', padx=6, pady=8)

        self._make_button(toolbar, '📋 复制局面', self.copy_board,
                          bg='#1e1e3a', fg='#c0c0e0', small=True).pack(side='left', padx=6, pady=8)

        cb_obs = tk.Checkbutton(toolbar, text='🚫 放置障碍', variable=self.is_obstacle_mode,
                            command=self._on_mode_change, bg=PANEL_BG, fg='#ff6666',
                            selectcolor=PANEL_BG, activebackground=PANEL_BG,
                            activeforeground='#ff6666', font=(self.cn_font, 9),
                            relief='flat', highlightthickness=0, cursor='hand2')
        cb_obs.pack(side='left', padx=10, pady=8)

        cb_line = tk.Checkbutton(toolbar, text='显示辅助线', variable=self.show_lines,
                            command=self.render, bg=PANEL_BG, fg=TEXT,
                            selectcolor=PANEL_BG, activebackground=PANEL_BG,
                            activeforeground=TEXT, font=(self.cn_font, 9),
                            relief='flat', highlightthickness=0, cursor='hand2')
        cb_line.pack(side='left', padx=10, pady=8)

        self.status_label = tk.Label(toolbar, text='就绪', bg=PANEL_BG, fg='#6666aa',
                                     font=(self.cn_font, 9), anchor='w')
        self.status_label.pack(side='left', padx=20)

        canvas_frame = tk.Frame(main, bg=BG)
        canvas_frame.pack(fill='both', expand=True)
        self.canvas = tk.Canvas(canvas_frame, bg=BG, highlightthickness=0)
        self.canvas.pack(fill='both', expand=True)

        self.canvas.bind('<Button-1>', self._on_left_press)
        self.canvas.bind('<B1-Motion>', self._on_left_drag)
        self.canvas.bind('<ButtonRelease-1>', self._on_left_release)
        self.canvas.bind('<Control-Button-1>', self._on_pan_press)
        self.canvas.bind('<Control-B1-Motion>', self._on_pan_drag)
        self.canvas.bind('<Control-ButtonRelease-1>', self._on_pan_release)
        self.canvas.bind('<Button-3>', self._on_right_press)
        self.canvas.bind('<B3-Motion>', self._on_right_drag)
        self.canvas.bind('<ButtonRelease-3>', self._on_right_release)
        self.canvas.bind('<Motion>', self._on_motion)
        self.canvas.bind('<Leave>', self._on_canvas_leave)
        self.canvas.bind('<Control-MouseWheel>', self._on_ctrl_wheel)
        self.root.bind('<Control-z>', self.undo)
        self.root.bind('<Control-Z>', self.undo)
        self.canvas.bind('<Configure>', lambda e: self._on_canvas_resize())

        log_frame = tk.Frame(main, bg='#0a0a14', height=110)
        log_frame.pack(fill='x')
        log_frame.pack_propagate(False)
        self.log_text = tk.Text(log_frame, bg='#0a0a14', fg='#888888', relief='flat', font=('Consolas', 9),
                                state='disabled', wrap='word', padx=14, pady=6)
        log_vsb = ttk.Scrollbar(log_frame, orient='vertical', command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_vsb.set)
        self.log_text.pack(side='left', fill='both', expand=True)
        log_vsb.pack(side='right', fill='y')
        self.log_text.tag_configure('err', foreground='#ff6666')
        self.log_text.tag_configure('ok', foreground='#55ff99')
        self.log_text.tag_configure('info', foreground='#88aaff')
        self.log_text.tag_configure('warn', foreground='#ffaa44')

    def _add_placeholder(self, entry, text):
        entry.insert(0, text)
        entry.config(fg='#555577')
        def on_focus_in(e):
            if entry.get() == text:
                entry.delete(0, 'end')
                entry.config(fg=TEXT)
        def on_focus_out(e):
            if not entry.get():
                entry.insert(0, text)
                entry.config(fg='#555577')
        entry.bind('<FocusIn>', on_focus_in)
        entry.bind('<FocusOut>', on_focus_out)

    def _make_button(self, parent, text, cmd, bg='#1e1e3a', fg='#c0c0e0', bold=False, small=False):
        f_size = 9 if small else 10
        font = (self.cn_font, f_size, 'bold') if bold else (self.cn_font, f_size)
        padx = 8 if small else 16
        pady = 2 if small else 6
        return tk.Button(parent, text=text, command=cmd, bg=bg, fg=fg,
                         activebackground=bg, activeforeground=fg,
                         relief='flat', bd=0, padx=padx, pady=pady,
                         font=font, cursor='hand2')

    def _toggle_topmost(self):
        on = bool(self.topmost_var.get())
        self.root.attributes('-topmost', on)
        self.log('窗口置顶：' + ('开启' if on else '关闭'), 'info')

    def _on_mode_change(self):
        if self.is_obstacle_mode.get():
            self.canvas.config(cursor="X_cursor")
        else:
            self.canvas.config(cursor="")

    def _toggle_disable(self):
        if not self.selected_aspect: return
        asp = ASPECTS[self.selected_aspect]
        asp['disabled'] = not asp.get('disabled', False)
        if asp['disabled']:
            self.log(f'已禁用「{asp["cn"]}」', 'warn')
        else:
            self.log(f'已启用「{asp["cn"]}」', 'ok')
        self._populate_tree()
        self._update_disable_button()
        self._update_status()

    def _update_disable_button(self):
        if not self.selected_aspect or self.selected_aspect not in ASPECTS:
            self.disable_btn.config(text='🚫 禁用此要素', state='disabled',
                                    bg='#1a1a2e', fg='#555555')
            return
        asp = ASPECTS[self.selected_aspect]
        if asp.get('disabled'):
            self.disable_btn.config(text='✅ 启用此要素', state='normal',
                                    bg='#1a3a1a', fg='#55ff99')
        else:
            self.disable_btn.config(text='🚫 禁用此要素', state='normal',
                                    bg='#3a2a1a', fg='#ffaa55')

    def _apply_cost(self, event=None):
        if not self.selected_aspect: return
        try:
            new_cost = float(self.cost_var.get())
            if new_cost < 0: raise ValueError
        except ValueError:
            self.log('权重必须是非负数', 'err'); return
        ASPECTS[self.selected_aspect]['cost'] = new_cost
        self.log(f'已将「{ASPECTS[self.selected_aspect]["cn"]}」权重设为 {new_cost}', 'info')
        self._populate_tree()
        self._on_tree_select()

    def _reset_costs(self):
        for k, v in DEFAULT_COSTS.items(): ASPECTS[k]['cost'] = v
        self.log('已恢复所有默认权重', 'warn')
        self._populate_tree()
        self._on_tree_select()

    def _init_grid(self):
        self.cells.clear()
        self.paths.clear()
        self.placed_order.clear()
        self.order_counter = 0
        for col in range(self.cols):
            for row in range(self.rows):
                q = col
                r = row - col // 2
                self.cells[(q, r)] = dict(q=q, r=r, aspect=None, fixed=False, order=-1, is_obstacle=False)

    def _compute_layout(self):
        w = self.canvas.winfo_width()
        h = self.canvas.winfo_height()
        if w < 10 or h < 10: w, h = 1100, 700
        
        sx = w / (1.5 * (self.cols - 1) + 2.5)
        sy = h / (math.sqrt(3) * (self.rows + 0.5) + 1.5)
        
        size = max(12.0, min(sx, sy, 50.0)) * self.zoom
        self.hex_size = size

        min_x = min_y = float('inf')
        max_x = max_y = float('-inf')
        for (q, r) in self.cells:
            px, py = axial_to_pixel(q, r, size)
            min_x = min(min_x, px - size)
            max_x = max(max_x, px + size)
            min_y = min(min_y, py - size * math.sqrt(3) / 2)
            max_y = max(max_y, py + size * math.sqrt(3) / 2)
        self.offset_x = (w - (max_x - min_x)) / 2.0 - min_x + self.pan_x
        self.offset_y = (h - (max_y - min_y)) / 2.0 - min_y + self.pan_y

    def _on_canvas_resize(self):
        self._compute_layout()
        self.render()

    def redraw(self):
        self._compute_layout()
        self.render()

    def _schedule_render(self):
        """拖拽时合并多次重绘，避免每个格子都全量刷新一次。"""
        if self._render_job is None:
            self._render_job = self.root.after(16, self._flush_render)

    def _flush_render(self):
        self._render_job = None
        self.render()

    def render(self):
        c = self.canvas
        c.delete('all')
        size = self.hex_size
        ox, oy = self.offset_x, self.offset_y

        for (q, r), cell in self.cells.items():
            px, py = axial_to_pixel(q, r, size)
            cx, cy = px + ox, py + oy
            
            fill = HEX_FILL if cell['aspect'] else HEX_EMPTY
            outline = BORDER
            width = 1
            
            if cell.get('is_obstacle'):
                fill = OBS_COLOR
                outline = OBS_LINE
                width = 2
                
            c.create_polygon(hex_polygon(cx, cy, size - 0.5), fill=fill, outline=outline, width=width)

            if (q, r) == self.hover_cell:
                c.create_polygon(hex_polygon(cx, cy, size - 2), fill='', outline='#5555aa', width=1.5)

            if cell.get('is_obstacle'):
                d = size * 0.4
                c.create_line(cx - d, cy - d, cx + d, cy + d, fill=OBS_LINE, width=2)
                c.create_line(cx - d, cy + d, cx + d, cy - d, fill=OBS_LINE, width=2)
                continue

            if cell['aspect']:
                asp = ASPECTS[cell['aspect']]
                border_color = GREEN if cell['fixed'] else YELLOW
                c.create_polygon(hex_polygon(cx, cy, size - 3), fill='', outline=border_color, width=2)
                cn_size = max(7, int(size * 0.44))
                text_color = '#aaffcc' if cell['fixed'] else '#ffeeaa'
                if asp.get('disabled'):
                    text_color = '#ff88aa'
                c.create_text(cx, cy, text=asp['cn'], fill=text_color,
                              font=(self.cn_font, cn_size, 'bold'))
                if size > 24:
                    en_size = max(5, int(size * 0.22))
                    c.create_text(cx, cy + size * 0.35, text=cell['aspect'],
                                  fill='#555577', font=('Consolas', en_size))

        if self.show_lines.get():
            line_points = {}
            for path in self.paths:
                coords = []
                for (q, r) in path:
                    px, py = axial_to_pixel(q, r, size)
                    coords.extend([px + ox, py + oy])
                    line_points[(q, r)] = line_points.get((q, r), 0) + 1
                if len(coords) >= 4:
                    c.create_line(coords, fill='#00304a', width=9, capstyle='round', joinstyle='round', smooth=True)
                    c.create_line(coords, fill=BLUE, width=2.5, capstyle='round', joinstyle='round', smooth=True)
            
            for (q, r), count in line_points.items():
                if count > 1:
                    px, py = axial_to_pixel(q, r, size)
                    c.create_oval(px+ox-3, py+oy-3, px+ox+3, py+oy+3, fill='#ffffff', outline='')

    def _pixel_to_axial(self, px, py):
        size = self.hex_size
        x = px - self.offset_x
        y = py - self.offset_y
        q = (2.0 / 3.0 * x) / size
        r = (-1.0 / 3.0 * x + math.sqrt(3) / 3.0 * y) / size
        return axial_round(q, r)

    def _on_motion(self, event):
        if self._panning or self.is_dragging_obstacle or self.is_dragging_erase: return
        q, r = self._pixel_to_axial(event.x, event.y)
        new_hover = (q, r) if (q, r) in self.cells else None
        if new_hover == self.hover_cell: return
        self.hover_cell = new_hover
        self._update_status()
        self.render()

    def _clear_hover(self):
        if self.hover_cell:
            self.hover_cell = None
            self._update_status()
            self.render()

    def _on_canvas_leave(self, _event=None):
        self.is_dragging_obstacle = False
        self.is_dragging_erase = False
        self._clear_hover()

    def _update_status(self):
        parts = []
        if self.selected_aspect:
            asp = ASPECTS[self.selected_aspect]
            dis = ' [🚫 已禁用]' if asp.get('disabled') else ''
            parts.append(f'选中：{asp["cn"]} ({self.selected_aspect}) [权重 {asp["cost"]}]{dis}')
        else:
            parts.append('未选择要素')

        if self.hover_cell and self.hover_cell in self.cells:
            cell = self.cells[self.hover_cell]
            if cell.get('is_obstacle'):
                parts.append(f'[障碍物] @ {self.hover_cell}')
            elif cell['aspect']:
                asp = ASPECTS[cell['aspect']]
                tag = '固定' if cell['fixed'] else '推算'
                dis = ' [禁用]' if asp.get('disabled') else ''
                parts.append(f'[{tag}] {asp["cn"]}{dis} @ {self.hover_cell}')
            else:
                parts.append(f'空格 @ {self.hover_cell}')
        self.status_label.config(text='   |   '.join(parts))

    def _on_left_press(self, event):
        """左键：放置要素；障碍模式下开始涂抹。Ctrl 拖动走平移绑定，不会触发这里。"""
        if getattr(event, 'state', 0) & 0x0004:
            return
        if self.is_obstacle_mode.get():
            q, r = self._pixel_to_axial(event.x, event.y)
            if (q, r) not in self.cells:
                return
            cell = self.cells[(q, r)]
            if cell['fixed']:
                self.log('该位置已有要素，无法放置障碍', 'err')
                return
            self.is_dragging_obstacle = True
            self._begin_stroke()
            if self._set_obstacle_at(q, r, True):
                self.log(f'放置障碍 ({q},{r})', 'warn')
            return
        self._place_aspect_at(event)

    def _on_left_drag(self, event):
        if not self.is_dragging_obstacle:
            return
        q, r = self._pixel_to_axial(event.x, event.y)
        if (q, r) not in self.cells:
            return
        self._set_obstacle_at(q, r, True)

    def _on_left_release(self, _event=None):
        self.is_dragging_obstacle = False
        self._end_stroke()

    def _place_aspect_at(self, event):
        q, r = self._pixel_to_axial(event.x, event.y)
        if (q, r) not in self.cells:
            return
        cell = self.cells[(q, r)]

        if not self.selected_aspect:
            self.log('请先在左侧列表中选择一个要素', 'warn')
            return
        if ASPECTS[self.selected_aspect].get('disabled'):
            self.log(f'「{ASPECTS[self.selected_aspect]["cn"]}」已禁用，无法放置', 'err')
            return
        if cell.get('is_obstacle'):
            self.log('当前位置有障碍，请先取消障碍', 'err')
            return

        self._push_undo()
        self._clear_computed()
        if cell['fixed']:
            self.log(f'替换 ({q},{r}) 的要素', 'warn')
        else:
            cell['order'] = self.order_counter
            self.order_counter += 1
            self.placed_order.append((q, r))

        cell['aspect'] = self.selected_aspect
        cell['fixed'] = True
        self._update_placed_list()
        self.log(f'放置「{ASPECTS[self.selected_aspect]["cn"]}」于 ({q}, {r})', 'info')
        self.render()

    # ---------- Ctrl + 左键拖动平移 ----------
    def _on_pan_press(self, event):
        self._panning = True
        self._last_pos = (event.x, event.y)

    def _on_pan_drag(self, event):
        if not self._panning or self._last_pos is None:
            return
        self.pan_x += event.x - self._last_pos[0]
        self.pan_y += event.y - self._last_pos[1]
        self._last_pos = (event.x, event.y)
        self._compute_layout()
        self.render()

    def _on_pan_release(self, _event=None):
        self._panning = False
        self._last_pos = None

    def _on_ctrl_wheel(self, event):
        """Ctrl + 滚轮缩放，以光标所在位置为中心。"""
        step = 1.15 if event.delta > 0 else (1.0 / 1.15)
        new_zoom = max(0.5, min(4.0, self.zoom * step))
        if abs(new_zoom - self.zoom) < 1e-9:
            return
        wx = (event.x - self.offset_x) / self.hex_size
        wy = (event.y - self.offset_y) / self.hex_size
        self.zoom = new_zoom
        self._compute_layout()
        self.pan_x += event.x - (wx * self.hex_size + self.offset_x)
        self.pan_y += event.y - (wy * self.hex_size + self.offset_y)
        self._compute_layout()
        self.render()
        self.status_label.config(text=f'缩放 {self.zoom:.2f}×（Ctrl+滚轮，左键拖动平移）')

    def copy_board(self):
        """把当前局面（固定要素 + 障碍）复制成 JSON，方便复现问题。"""
        data = {
            'nodes': [[c['q'], c['r'], c['aspect']]
                      for c in self.cells.values() if c['fixed'] and c['aspect']],
            'obstacles': [[c['q'], c['r']]
                          for c in self.cells.values() if c.get('is_obstacle')],
        }
        text = json.dumps(data, ensure_ascii=False)
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            self.log(f'局面已复制到剪贴板（{len(data["nodes"])} 个要素）', 'ok')
        except tk.TclError as exc:
            self.log(f'复制失败：{exc}', 'err')

    def _toggle_sidebar(self):
        "收起/展开左侧栏，小窗口或盖在游戏上时可以只留画布。"
        if self.sidebar.winfo_ismapped():
            self.sidebar.pack_forget()
            self.log('侧栏已收起（再点「☰ 侧栏」恢复）', 'info')
        else:
            self.sidebar.pack(side='left', fill='y', before=self.main_area)
            self.log('侧栏已展开', 'info')
        self.root.after(50, self._on_canvas_resize)

    def reset_view(self):
        self.zoom = 1.0
        self.pan_x = 0.0
        self.pan_y = 0.0
        self._compute_layout()
        self.render()
        self.log('视图已重置（缩放 1.0×）', 'info')

    def _on_right_press(self, event):
        q, r = self._pixel_to_axial(event.x, event.y)
        if (q, r) not in self.cells:
            self.is_dragging_erase = False
            return
        cell = self.cells[(q, r)]

        if self.is_obstacle_mode.get():
            self.is_dragging_erase = True
            self._begin_stroke()
            if self._set_obstacle_at(q, r, False):
                self.log(f'移除障碍 ({q},{r})', 'info')
            return

        self.is_dragging_erase = False
        if cell['fixed']:
            self._push_undo()
            self._clear_computed()
            cell['aspect'] = None
            cell['fixed'] = False
            cell['order'] = -1
            if (q, r) in self.placed_order: self.placed_order.remove((q, r))
            self._update_placed_list()
            self.log(f'移除要素 ({q},{r})', 'warn')
            self.render()
        elif cell.get('is_obstacle'):
            if self._set_obstacle_at(q, r, False):
                self.log(f'移除障碍 ({q},{r})', 'info')

    def _on_right_drag(self, event):
        if not self.is_dragging_erase: return
        q, r = self._pixel_to_axial(event.x, event.y)
        if (q, r) not in self.cells: return
        self._set_obstacle_at(q, r, False)

    def _on_right_release(self, _event=None):
        self.is_dragging_erase = False
        self._end_stroke()

    def _set_obstacle_at(self, q, r, value):
        cell = self.cells.get((q, r))
        if cell is None: return False
        if value and cell['fixed']: return False
        if cell.get('is_obstacle', False) == value: return False
        if self._stroke_snapshot is not None:
            self._stroke_dirty = True
        else:
            self._push_undo()
        self._clear_computed()
        cell['is_obstacle'] = value
        self._schedule_render()
        return True

    def _clear_computed(self):
        for cell in self.cells.values():
            if not cell['fixed']: cell['aspect'] = None
        self.paths.clear()

    def _populate_tree(self):
        tree = getattr(self, 'tree', None)
        if tree is None:   # 启动时 search_var 的 trace 可能先于 tree 创建触发
            return
        for iid in tree.get_children(''): tree.delete(iid)
        
        kw = self.search_var.get().strip().lower()
        if kw == "输入名称 / 拼音 / 首字母...": kw = ""
            
        by_tier = {}
        for key, asp in ASPECTS.items():
            cn = asp['cn']
            py_full = asp.get('py_full', '')
            py_short = asp.get('py_short', '')
            if kw and (kw not in key.lower() and kw not in cn
                       and kw not in py_full and kw not in py_short):
                continue
            by_tier.setdefault(asp['tier'], []).append(key)

        for tier in sorted(by_tier):
            parent = tree.insert('', 'end', iid=f'__tier{tier}__',
                                 text=f'Tier {tier}  ({len(by_tier[tier])})', open=True)
            for key in sorted(by_tier[tier], key=lambda k: (ASPECTS[k]['cost'], k)):
                asp = ASPECTS[key]
                display = asp['cn']
                tags = ()
                if asp.get('disabled'):
                    display = '🚫 ' + display
                    tags = ('disabled',)
                tree.insert(parent, 'end', iid=key, text=display,
                            values=(key, asp['cost']), tags=tags)

        if self.selected_aspect and tree.exists(self.selected_aspect):
            tree.selection_set(self.selected_aspect)

    def _on_tree_click(self, _event=None):
        "点左侧列表选要素时，自动关掉「放置障碍」，避免点画布误刷红叉。"
        def finish():
            sel = self.tree.selection()
            if not sel:
                return
            iid = sel[0]
            if iid.startswith('__tier'):
                return
            if self.is_obstacle_mode.get():
                self.is_obstacle_mode.set(False)
                self._on_mode_change()
                self.log('已切换到要素模式（自动关闭「放置障碍」）', 'info')
        self.root.after(1, finish)

    def _on_tree_select(self, _event=None):
        sel = self.tree.selection()
        if not sel:
            self.edit_label.config(text='选中要素以修改权重')
            self.cost_var.set('')
            self.selected_aspect = None
            self._update_disable_button()
            return
        iid = sel[0]
        if iid.startswith('__tier'):
            self.tree.selection_remove(iid)
            return
        self.selected_aspect = iid
        asp = ASPECTS[iid]
        dis = ' [已禁用]' if asp.get('disabled') else ''
        self.edit_label.config(text=f'{asp["cn"]} ({iid}){dis}')
        self.cost_var.set(str(asp['cost']))
        self._update_disable_button()
        self._update_status()

    def _update_placed_list(self):
        tree = self.placed_tree
        for iid in tree.get_children(''): tree.delete(iid)
        sorted_order = sorted(self.placed_order, key=lambda p: self.cells[p]['order'])
        for i, (q, r) in enumerate(sorted_order):
            cell = self.cells[(q, r)]
            if not cell['fixed'] or not cell['aspect']: continue
            asp = ASPECTS[cell['aspect']]
            tree.insert('', 'end', iid=f'{q},{r}', text=f'{i + 1}. {asp["cn"]} ({q},{r})')

    def _on_placed_double_click(self, _event=None):
        sel = self.placed_tree.selection()
        if not sel: return
        try: q, r = map(int, sel[0].split(','))
        except ValueError: return
        cell = self.cells.get((q, r))
        if cell and cell['fixed']:
            self._push_undo()
            self._clear_computed()
            cell['aspect'] = None
            cell['fixed'] = False
            cell['order'] = -1
            if (q, r) in self.placed_order: self.placed_order.remove((q, r))
            self._update_placed_list()
            self.log(f'移除 ({q},{r})', 'warn')
            self.render()

    # ---------- 操作记录 / 撤回 ----------
    def _snapshot(self):
        return {
            'cells': {k: (c['aspect'], c['fixed'], c['order'], c.get('is_obstacle', False))
                      for k, c in self.cells.items()},
            'placed_order': list(self.placed_order),
            'order_counter': self.order_counter,
            'paths': [list(p) for p in self.paths],
        }

    def _push_undo(self, snap=None):
        self._undo_stack.append(snap or self._snapshot())
        if len(self._undo_stack) > 100:
            self._undo_stack.pop(0)

    def _begin_stroke(self):
        if self._stroke_snapshot is None:
            self._stroke_snapshot = self._snapshot()
            self._stroke_dirty = False

    def _end_stroke(self):
        if self._stroke_snapshot is not None and self._stroke_dirty:
            self._push_undo(self._stroke_snapshot)
        self._stroke_snapshot = None
        self._stroke_dirty = False

    def _restore_snapshot(self, snap):
        for k, c in self.cells.items():
            a, f, o, ob = snap['cells'].get(k, (None, False, -1, False))
            c['aspect'] = a
            c['fixed'] = f
            c['order'] = o
            c['is_obstacle'] = ob
        self.placed_order = list(snap['placed_order'])
        self.order_counter = snap['order_counter']
        self.paths = [list(p) for p in snap['paths']]
        self._update_placed_list()
        self.hover_cell = None
        self.render()

    def undo(self, event=None):
        self._stroke_snapshot = None
        self._stroke_dirty = False
        if not self._undo_stack:
            self.log('没有可撤回的操作', 'warn')
            return 'break'
        snap = self._undo_stack.pop()
        self._restore_snapshot(snap)
        self.log(f'已撤回上一步（还可撤回 {len(self._undo_stack)} 步）', 'warn')
        return 'break'

    # ================= 核心：紧凑主干生长 + 联合 A* =================
    # 规则实现：
    #   [物理层] 不穿障碍、不穿未接入的绿点；路径步数与起终点直线距离奇偶一致
    #   [逻辑层] 相邻要素必须在要素图中相连、不得连续同名；禁用要素不作中间点
    #   [网络层] 中位点生根 + 每轮取全局最便宜接入 + 建完重接，尽量少铺黄格
    TURN_PENALTY = 0.05    # 转弯惩罚（现在只作为“权重相同”时的次级偏好）
    WEIGHT_EPS = 1e-6      # 权重缩放系数：步数 >> 权重 >> 转弯，权重总和最多加 0.2，不会多走格子
    SEARCH_TIMEOUT = 1.0   # 单条连线的搜索时间上限
    TOTAL_TIMEOUT = 120.0  # 整次运算的总时间上限

    def _board_signature(self):
        """棋盘快照签名：用于判断计算期间地图是否被改动。"""
        return tuple((k, c['aspect'], c['fixed'], c['order'], c.get('is_obstacle', False))
                     for k, c in sorted(self.cells.items()))

    def _distance_field(self, cells, network_cells):
        """多源 BFS：每个格子到最近主干格子的六边形步数，作为 A* 的可采纳启发。"""
        dist = {c: 0 for c in network_cells}
        dq = collections.deque(network_cells)
        while dq:
            cq, cr = dq.popleft()
            nd = dist[(cq, cr)] + 1
            for dq_, dr_ in HEX_DIRS:
                nk = (cq + dq_, cr + dr_)
                if nk not in cells or nk in dist:
                    continue
                dist[nk] = nd
                dq.append(nk)
        return dist

    def _reconstruct_path(self, parent, state):
        cells, aspects = [], []
        cur = state
        while cur is not None:
            q, r, a, _d, _p = cur
            cells.append((q, r))
            aspects.append(a)
            cur = parent[cur]
        cells.reverse()
        aspects.reverse()
        return cells, aspects

    def _find_path_to_network(self, start, cells, network_cells, network_aspects, deadline):
        """A*：从 start 出发，寻找一条接入主干任意合法节点的最短路径。

        返回 (path_cells, path_aspects, error)；path 含起点与接入点。
        """
        start_asp = cells[start]['aspect']
        if start_asp is None:
            return None, None, '起点没有要素'

        dist = self._distance_field(cells, network_cells)
        ban_cache = {}
        blocked_fixed = {k for k, c in cells.items() if c['fixed'] and k not in network_cells}

        # 状态：(q, r, 当前要素, 上一步方向)
        init = (start[0], start[1], start_asp, None, 0)
        parent = {init: None}
        best = {init: 0.0}
        pq = [(dist.get(start, 0), 0.0, 0, start[0], start[1], start_asp, None)]
        t0 = time.time()

        while pq:
            now = time.time()
            if now - t0 > self.SEARCH_TIMEOUT or now > deadline:
                return None, None, '搜索超时'
            f, cost, steps, q, r, asp, pdir = heapq.heappop(pq)
            state = (q, r, asp, pdir, steps & 1)
            if cost > best.get(state, 1e18):
                continue

            # 到达主干：必须已通过合法性校验，且步数奇偶与直线距离一致
            if (q, r) in network_cells and steps > 0 and (q, r) != start:
                d = hex_distance(start, (q, r))
                if (steps - d) % 2 == 0:
                    pc, pa = self._reconstruct_path(parent, state)
                    return pc, pa, None
                continue

            for dq_, dr_ in HEX_DIRS:
                nq, nr = q + dq_, r + dr_
                if (nq, nr) not in cells:
                    continue
                ncell = cells[(nq, nr)]
                if ncell.get('is_obstacle'):
                    continue
                # 禁止穿过其他未接入的绿点（目标网络节点除外）
                if (nq, nr) in blocked_fixed:
                    continue
                entering_network = (nq, nr) in network_cells
                banned = ban_cache.get((nq, nr))
                if banned is None:
                    banned = set()
                    for _dq, _dr in HEX_DIRS:
                        nk = (nq + _dq, nr + _dr)
                        if nk == (q, r):
                            continue
                        _na = network_aspects.get(nk)
                        if _na:
                            banned.add(_na)
                        elif nk in cells and nk not in network_cells and cells[nk]['aspect']:
                            banned.add(cells[nk]['aspect'])
                    ban_cache[(nq, nr)] = banned

                for na in ASPECTS[asp]['neighbors']:
                    if na == asp:                     # 避重：不得连续同名
                        continue
                    if entering_network:
                        # 只能接在要素匹配的主干节点上，且到此为止（不穿越主干）
                        if network_aspects.get((nq, nr)) != na:
                            continue
                    else:
                        if ASPECTS[na].get('disabled'):   # 禁用要素绝不能作中间点
                            continue
                        if ncell['fixed'] and ncell['aspect'] != na:
                            continue
                        if ncell['aspect'] and ncell['aspect'] != na:
                            continue
                        if na in banned:                  # 全局避重（邻居缓存）
                            continue

                    nsteps = steps + 1
                    turn = 0.0 if (pdir is None or (dq_, dr_) == pdir) else self.TURN_PENALTY
                    if getattr(self, '_cost_mode', 'w') == 'w':
                        # 权重优先：每格固定 1 分 + 权重×0.05
                        ncost = cost + 1.0 + ASPECTS[na]['cost'] * 0.05
                    else:
                        # 格数优先（用于对照，找出“更少格数且不吃亏”的方案）
                        ncost = (cost + 1.0
                                 + (ASPECTS[na]['cost'] + turn * 0.05) * self.WEIGHT_EPS)
                    nstate = (nq, nr, na, (dq_, dr_), nsteps & 1)
                    if ncost >= best.get(nstate, 1e18):
                        continue
                    best[nstate] = ncost
                    parent[nstate] = state
                    h = dist.get((nq, nr), 0)
                    heapq.heappush(pq, (ncost + h, ncost, nsteps, nq, nr, na, (dq_, dr_)))

        return None, None, '物理阻挡/无合法要素链路'

    def _pick_root(self, fixed_cells, cells):
        """中位点生根：选“到其他绿点总距离最小”的点，避免长出超长主枝。"""
        keys = [(c['q'], c['r']) for c in fixed_cells]
        best = None
        best_key = None
        for k in keys:
            total = sum(hex_distance(k, o) for o in keys)
            cand = (total, cells[k]['order'])
            if best_key is None or cand < best_key:
                best_key = cand
                best = k
        return best

    def _corridor_bias(self, remaining, cells):
        """未来走廊加分：离未接入绿点 2 格以内的格子更值得走，方便后续分叉。"""
        bias = {}
        for g in remaining:
            q, r = g
            for dq in range(-2, 3):
                for dr in range(-2, 3):
                    c = (q + dq, r + dr)
                    if c in cells and hex_distance(c, g) <= 2:
                        bias[c] = bias.get(c, 0) + 1
        return bias

    def _grow_from_root(self, cells, fixed_cells, root_key, deadline, rng=None):
        """Prim 式生长：每轮在所有未接入点里取“真实路径最短”的接入。"""
        network = {root_key}
        netasp = {root_key: cells[root_key]['aspect']}
        remaining = [(c['q'], c['r']) for c in fixed_cells if (c['q'], c['r']) != root_key]
        remaining.sort(key=lambda k: cells[k]['order'])
        order_key = {k: cells[k]['order'] for k in remaining}
        if rng is not None:
            order_key = {k: rng.random() for k in remaining}
        results = []

        while remaining:
            bias = self._corridor_bias(remaining, cells)
            heap = []
            for t in remaining:
                lb = min(hex_distance(t, n) for n in network)
                heap.append((lb, order_key[t], t))
            heapq.heapify(heap)

            best = None   # (步数, -走廊分, 顺序, 起点, 路径, 要素)
            while heap:
                lb, _od, t = heapq.heappop(heap)
                if best is not None and lb >= best[0]:
                    break
                path, asps, err = self._find_path_to_network(t, cells, network, netasp, deadline)
                if err:
                    continue
                corridor = sum(bias.get(c, 0) for c in path[1:-1])
                wsum = sum(ASPECTS[a]['cost'] for a in asps[1:-1])
                if getattr(self, '_cost_mode', 'w') == 'w':
                    cand = (wsum, len(path) - 1, -corridor, order_key[t], t, path, asps)
                else:
                    cand = (len(path) - 1, wsum, -corridor, order_key[t], t, path, asps)
                if best is None or cand < best:
                    best = cand
                if best[0] == lb:      # 已经达到该点的理论下界，不可能更短
                    break

            if best is None:
                for t in remaining:
                    results.append((t, None, None, '无法接入主干'))
                break

            if getattr(self, '_cost_mode', 'w') == 'w':
                _w, _l, _c, _o, t, path, asps = best
            else:
                _l, _w, _c, _o, t, path, asps = best
            for k, a in zip(path, asps):
                network.add(k)
                netasp[k] = a
            remaining.remove(t)
            for k in path:              # 终点若正好是别的绿点，也一并接入
                if k in remaining:
                    remaining.remove(k)
            results.append((t, path, asps, None))

        return results, network, netasp

    def _tree_valid(self, results, fixed_keys, root_key):
        """检查当前这组路径是否仍是一棵覆盖所有绿点的树（连通、无环）。"""
        adj = {}
        for _g, p, _a, e in results:
            if e or not p:
                continue
            for x, y in zip(p, p[1:]):
                adj.setdefault(x, set()).add(y)
                adj.setdefault(y, set()).add(x)
        if root_key not in adj:
            return False
        seen = set()
        stack = [root_key]
        while stack:
            x = stack.pop()
            if x in seen:
                continue
            seen.add(x)
            stack.extend(adj.get(x, ()) - seen)
        edges = sum(len(v) for v in adj.values()) // 2
        if edges != len(seen) - 1:      # 有环，或连通块不止一个
            return False
        return all(k in seen for k in fixed_keys)

    def _rewire(self, cells, results, network, netasp, deadline, root_key, fixed_keys):
        """后处理：拆下支路重接，按“权重优先、格数其次”判断是否更省，消掉浪费。"""
        improved_count = 0
        for _round in range(2):
            if time.time() > deadline:
                break
            improved = False
            for i in range(len(results) - 1, -1, -1):
                g, path, asps, err = results[i]
                if err or not path or len(path) < 3:
                    continue
                interior = path[1:-1]
                busy = False
                for j, (_g2, p2, _a2, _e2) in enumerate(results):
                    if j == i or not p2:
                        continue
                    if g in p2 or p2[-1] in interior or any(c in interior for c in p2[1:-1]):
                        busy = True
                        break
                if busy:
                    continue

                old_w = sum(ASPECTS[a]['cost'] for a in asps[1:-1])
                old_c = len(path) - 1
                net_before = set(network)
                asp_before = dict(netasp)

                network.discard(g)
                netasp.pop(g, None)
                for c in interior:
                    network.discard(c)
                    netasp.pop(c, None)

                new_path, new_asps, err2 = self._find_path_to_network(
                    g, cells, network, netasp, deadline)

                ok = False
                if err2 is None and new_path:
                    new_w = sum(ASPECTS[a]['cost'] for a in new_asps[1:-1])
                    new_c = len(new_path) - 1
                    if (new_w, new_c) < (old_w, old_c):
                        for c, a in zip(new_path, new_asps):
                            network.add(c)
                            netasp[c] = a
                        results[i] = (g, new_path, new_asps, None)
                        ok = self._tree_valid(results, fixed_keys, root_key)

                if not ok:
                    results[i] = (g, path, asps, None)
                    network.clear(); network.update(net_before)
                    netasp.clear(); netasp.update(asp_before)
                    continue
                improved = True
                improved_count += 1
            if not improved:
                break
        return improved_count

    def auto_connect(self):
        if self._computing:
            self.log('正在计算中，请稍候……', 'warn')
            return

        fixed_cells = sorted([c for c in self.cells.values() if c['fixed'] and c['aspect']],
                             key=lambda c: c['order'])
        if len(fixed_cells) < 2:
            self.log('至少需要放置 2 个要素才能连线', 'err')
            return

        self._push_undo()
        self._clear_computed()
        self.render()

        self._computing = True
        self.connect_btn.config(state='disabled', text='计算中...')
        self.status_label.config(text='正在生长网络主干...')
        self.log('开始生长网络主干（中位点生根 + 全局最便宜接入）…', 'info')

        # 传给工作线程的只读快照：工作线程不访问任何 Tk / 可变 UI 数据
        snapshot = {k: dict(v) for k, v in self.cells.items()}
        sig = self._board_signature()
        root_key = self._pick_root(fixed_cells, snapshot)

        def worker():
            try:
                results, elapsed = self._grow_network(snapshot, fixed_cells, root_key)
                self._result_queue.put((results, elapsed, sig))
            except Exception as exc:  # 后台异常不能把界面拖死
                self._result_queue.put((None, 0.0, sig, repr(exc)))

        threading.Thread(target=worker, daemon=True).start()
        self.root.after(60, self._poll_results)

    def _grow_network(self, cells, fixed_cells, root_key):
        t_start = time.time()
        deadline = t_start + 5.0    # 单次自动连线最多算 5 秒，避免卡太久
        keys = [(c['q'], c['r']) for c in fixed_cells]
        if len(keys) <= 1:
            results, _n, _a = self._grow_from_root(cells, fixed_cells, root_key, deadline)
            return results, time.time() - t_start

        roots = [root_key]
        far = max(keys, key=lambda x: sum(hex_distance(x, o) for o in keys))
        for k in (far,):
            if k not in roots:
                roots.append(k)

        def score(results):
            fails = sum(1 for r in results if r[3])
            total = sum(len(r[1]) - 1 for r in results if r[1])
            wsum = 0
            cnt = collections.Counter()
            for r in results:
                if not r[3]:
                    wsum += sum(ASPECTS[a]['cost'] for a in r[2][1:-1])
                    cnt.update(r[2][1:-1])
            dups = sum(v - 1 for v in cnt.values() if v > 1)
            return (fails, wsum, total, dups)

        best = None
        for rk in roots:
            self._cost_mode = 'w'
            results, network, netasp = self._grow_from_root(cells, fixed_cells, rk, deadline)
            key = score(results)
            if best is None or key < best[0]:
                best = (key, results, network, netasp, rk)
            if time.time() - t_start > 4.5:   # 第一轮太慢就不再试别的起点
                break

        # 浪费检查：用“格数优先”跑一遍，若总权重不升且格数更少则替换
        self._cost_mode = 'c'
        results, network, netasp = self._grow_from_root(cells, fixed_cells, root_key, deadline)
        key = score(results)
        if best is None or key < best[0]:
            best = (key, results, network, netasp, root_key)

        key, results, network, netasp, rk = best
        self._opt_count = 0
        if key[0] == 0:
            self._opt_count = self._rewire(cells, results, network, netasp, deadline, rk, keys)
        return results, time.time() - t_start

    def _poll_results(self):
        try:
            payload = self._result_queue.get_nowait()
        except queue.Empty:
            self.root.after(60, self._poll_results)
            return

        self._computing = False
        if len(payload) == 4:
            self._finish_error(f'后台计算异常：{payload[3]}')
            return

        results, elapsed, sig = payload
        if sig != self._board_signature():
            self.log('地图在计算期间被改动，本次结果已作废', 'warn')
            self.status_label.config(text='地图已改动，请重新计算')
            self.connect_btn.config(state='normal', text='⚡ 自动连线')
            return
        self._apply_results(results, elapsed)

    def _finish_error(self, msg):
        self.log(msg, 'err')
        self.status_label.config(text='计算失败')
        self.connect_btn.config(state='normal', text='⚡ 自动连线')

    def _apply_results(self, results, elapsed):
        ok = 0
        total = len(results)
        for start_cell, path_cells, path_aspects, error in results:
            cn = ASPECTS[self.cells[start_cell]['aspect']]['cn']
            if error:
                self.log(f'✗ {cn} {start_cell} 无法接入主干：{error}', 'err')
                continue
            ok += 1
            steps = len(path_cells) - 1
            self.log(f'✓ {cn} {start_cell} 接入主干，新增 {steps} 步', 'ok')
            for i in range(1, len(path_cells) - 1):
                cell = self.cells[path_cells[i]]
                if cell['fixed']:
                    continue
                cell['aspect'] = path_aspects[i]
            self.paths.append(path_cells)

        self.log('浪费检查：已对比“权重优先/格数优先”两套方案，取总权重与格数更优者', 'info')
        cnt = collections.Counter()
        for _p in self.paths:
            for _c in _p[1:-1]:
                cnt[ASPECTS[self.cells[_c]['aspect']]['cn']] += 1
        rep = [f'{k}×{v}' for k, v in cnt.items() if v > 1]
        if rep:
            self.log('重复要素：' + '、'.join(rep), 'warn')
        opt = getattr(self, '_opt_count', 0)
        if opt:
            self.log(f'浪费检查：后处理消掉 {opt} 处绕路/多余连接', 'ok')
        if total:
            msg = f'主干生长完成：{ok}/{total} 个节点接入（{elapsed:.2f}s）'
        else:
            msg = f'主干生长完成（{elapsed:.2f}s）'
        tag = 'ok' if ok == total else ('warn' if ok else 'err')
        self.log(msg, tag)
        self.status_label.config(text=msg)
        self.connect_btn.config(state='normal', text='⚡ 自动连线')
        self.render()

    def clear_all(self):
        self._push_undo()
        for cell in self.cells.values():
            cell['aspect'] = None
            cell['fixed'] = False
            cell['order'] = -1
            cell['is_obstacle'] = False
        self.paths.clear()
        self.placed_order.clear()
        self.order_counter = 0
        self.selected_aspect = None
        self.placed_tree.delete(*self.placed_tree.get_children())

        sel = self.tree.selection()
        if sel: self.tree.selection_remove(*sel)

        self.log('已清空全部', 'warn')
        self.render()

    def log(self, msg, tag=''):
        t = time.strftime('%H:%M:%S')
        self.log_text.configure(state='normal')
        self.log_text.insert('end', f'[{t}] {msg}\n', tag)
        self.log_text.see('end')
        self.log_text.configure(state='disabled')

def main():
    root = tk.Tk()
    app = HexAspectApp(root)
    app.log('工具已就绪 —— 已启用【主干生长 + 联合 A*】模式', 'info')
    app.log('提示：绿点会按“就近优先”并入主干，只分叉、不重复铺线', 'info')
    app.log('窗口默认置顶，可直接盖在游戏上（游戏请用窗口化/无边框模式）', 'info')
    app.log('Ctrl+滚轮缩放，Ctrl+左键拖动平移视图；工具栏「重置视图」可还原', 'info')
    app.log('Ctrl+Z 或工具栏「↶ 撤回」可以撤销上一步操作（最多 100 步）', 'info')
    root.mainloop()

if __name__ == '__main__':
    main()